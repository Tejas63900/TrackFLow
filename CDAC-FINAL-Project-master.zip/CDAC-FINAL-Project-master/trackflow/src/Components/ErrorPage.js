import React from 'react'

export default function ErrorPage() {
  return (
    <div><h1 className='text-danger'>Server Side Error!@!!!</h1></div>
  )
}
